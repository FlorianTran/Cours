<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Teacher extends CI_Controller {


	public function __construct()
	{
		parent::__construct();
		//Si besoin por debuguer
		//$this->output->enable_profiler(TRUE);
		//TODO
		//TODO
	}

	public function index()
	{
		//TODO
	}

	public function increase($name)
	{
		//TODO
			}
	public function decrease($name)
	{
		//TODO
	}

	public function add(){
		//TODO
	}

}
