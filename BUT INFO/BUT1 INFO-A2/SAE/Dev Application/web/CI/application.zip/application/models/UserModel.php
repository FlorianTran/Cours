<?php
require_once APPPATH.'models'.DIRECTORY_SEPARATOR."UserEntity.php";
class UserModel extends CI_Model {

    function findByPseudo(string $pseudo): ?UserEntity{
        $request="select * from user where pseudo=?";
        $q=$this->db->query($request, array($pseudo));
        $response = $q->custom_result_object("UserEntity");
        return $response[0];
    }
}