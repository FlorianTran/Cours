<!doctype html>
<html lang="fr">
<head>
    <meta charset="utf-8">
    <title>Ajout magasin</title>
</head>
<body>
<p> <a href="<?="./../../"?> "> Home </a></p>
<form action="<?='./addProduct'?>" method="post">
    <input type="text" name="id" placeholder="id" required>
    <input type="text" name="name" placeholder="name" required>
    <input type="text" name="price" placeholder="price" required>
    <input type="text" name="quantity" placeholder="quantity">
    <!-- QUANTITY N'EST PAS REQUIRED? -->
    <input type="submit">
</form>
</body>
</html>