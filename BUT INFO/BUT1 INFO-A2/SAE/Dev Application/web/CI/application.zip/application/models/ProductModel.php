<?php
require_once APPPATH.'models'.DIRECTORY_SEPARATOR."ProductEntity.php";
class ProductModel extends CI_Model {

    function findAll(){
        $this->db->select('*');
        $q = $this->db->get('product');
        $response = $q-> custom_result_object("ProductEntity");
        return $response;
    }

    function findById(int $id):?ProductEntity{
        $req ="select * from product where id=?";
        $q = $this->db->query($req, array($id));
        $response=$q->custom_result_object("ProductEntity");
        return $response[0];

    }

    function add(int $id, string $name, float $price, int $quantity){
        $req="insert into product (id, name, price, quantity) values (?, ?, ?, ?)";
        $this->db->query($req, array($id, $name, $price, $quantity));
    }
    
    function delete(int $id){
        $req="delete from product where id=?";
        $this->db->query($req, array($id));
    }

    function update(int $id, string $name, float $price, int $quantity){
        $req="update product set name=?, price=?, quantity=? where id=?";
        $this->db->query($req, array($name, $price, $quantity, $id));
    }
    // PENSER A TRAITER LES POTENTIELLES ERREURES SQL

}