<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<!doctype html>
<html lang="fr">
<head>
    <meta charset="utf-8">
    <title>Mon magasin</title>
</head>
<body>
    <h1> Access Denied</h1>
<p> <a href="<?= "index.php/Welcome/index"?>"> Home </a></p>
</body>
</html>
