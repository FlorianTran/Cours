<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<!doctype html>
<html lang="fr">
<head>
    <meta charset="utf-8">
    <title>Sheeeesh2</title>
</head>
<body>
<p> <a href="<?="./../../../"?>"> Home </a></p>
<table>
    <thead>
    <tr>
        <th> id </th>
        <th> name </th>
        <th> price </th>
        <th> quantity </th>
    </tr>
    </thead>
    <tbody>

    <tr>
        <td> <?= $id?> </td>
        <td> <?= $name ?> </td>
        <td> <?= $price ?> </td>
        <td> <?= $quantity ?> </td>
    </tr>

    </tbody>
</table>
   <style>
        table,
        td {
            background-color: #fff;
            text-align:center;
        }

        thead,
        tfoot {
            background-color: #fff;
        }
        table {
            background-color: #333;
        }
    </style>

</body>
</html>
