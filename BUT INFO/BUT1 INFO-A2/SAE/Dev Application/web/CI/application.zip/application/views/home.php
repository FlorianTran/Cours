<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<?php
  session_start(); // must be before any output
  if(isset($_SESSION['login'])) $username = $_SESSION['login']["pseudo"]; 
?>
</html>
<!doctype html>
<html lang="fr">
<link rel="stylesheet" href="./../scripts/script.css">
<head>
    <meta charset="utf-8">
    <title>Mon magasin</title>
</head>
<body>
<nav>
    <ul>
            <!-- <h4>Hello <?=$username ?></h4> -->
            <li> <a href="<?='index.php/User/logout'?>">  Logout </a></li>
            <li> <a href="<?='index.php/Product/add'?>"> Add product </a> </li>
        
        <li> <a href="<?='index.php/User/login'?>"> Login </a></li>
        
    </ul>
</nav>
<table>
    <thead>
        <tr>
            <th> id </th>
            <th> name </th>
            <th> price </th>
            <th> quantity </th>
            <?php
            if(isset($_SESSION['login'])&&$_SESSION["login"]["status"]=="Administrator"){
            ?>
                <th> update </th>
                <th> delete </th>
            <?php } ?>
        </tr>
    </thead>
    <tbody>
    <?php foreach ($allproducts as $product):?>
       <tr>
        <td> <?= $product->getId() ?> </td>
        <td> <a href="<?='index.php/Product/display/'.$product->getId() ?>"><?= $product->getName() ?></a> </td>
        <td> <?= $product->getPrice() ?> </td>
        <td> <?= $product->getQuantity() ?> </td>
        <td> <a href="<?='index.php/Product/update/'.$product->getId() ?>"> update </a></td>
        <td> <a href="<?='index.php/Product/delete/'.$product->getId() ?>"> delete </a></td>
       </tr>
    <?php endforeach;
    ?>
    </tbody>
</table>
</body>
<style>
        table,
        td {
            background-color: #fff;
            text-align:center;
        }

        thead,
        tfoot {
            background-color: #fff;
        }
        table {
            background-color: #333;
        }
    </style>
</html>
