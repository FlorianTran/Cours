<?php
  defined('BASEPATH') OR exit('No direct script access allowed');
?>
<!doctype html>
<html lang="fr">
<head>
    <meta charset="utf-8">
    <title>Modification produit</title>
</head>
<body>
<p> <a href="<?="./../../.."?> "> Home </a></p>
<form action="<?='./../../product/updateProduct'?>" method="post">
    <input type="text" name="id" value="<?=$id?>" readonly>
    <input type="text" name="name" value="<?=$name?>" placeholder="name" required>
    <input type="text" name="price" value="<?=$price?>" placeholder="price" required>
    <input type="text" name="quantity" value="<?=$quantity?>" placeholder="quantity">
    <!-- ICI, QUANTITY N'EST PAS REQUIRED (0 DOIT ETRE MIS EN CAS DE NULL) -->
    <input type="submit">
</form>
</body>
</html>
  