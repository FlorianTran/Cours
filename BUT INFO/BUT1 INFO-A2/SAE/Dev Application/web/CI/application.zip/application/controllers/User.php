<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class User extends CI_Controller {

	public function login(){	
		$this->load->view('login');
	}

	public function loginCheck(){
		$pseudo = $_POST['login'];
        $password = $_POST ['password'];
        $this->load->model('UserModel');
        $user = $this->UserModel->findByPseudo($pseudo);
        if ($user !=null && $user->isValidPassword($password)) {
            session_start();
            $_SESSION['login']=array("pseudo"=>$user->getPseudo(), "status"=>$user->getStatus());
            $this->load->view("home");
            die();
        }
        $this->load->view("accessDenied");
	}

	public function logout(){
	}
}
