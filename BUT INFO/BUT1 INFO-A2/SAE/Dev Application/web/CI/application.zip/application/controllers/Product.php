<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Product extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/userguide3/general/urls.html
	 */

	public function display(int $id){
		$data['id']=$id;
		$this->load->model('ProductEntity');
		$this->load->model('ProductModel');
		$product=$this->ProductModel->findById($id);
		$data['name']=$product->getName();
		$data['price']=$product->getPrice();
		$data['quantity']=$product->getQuantity();
		$this->load->view('displayProduct', $data);
	}

	public function add(){
		$this->load->view('addProduct');
	}

	public function addProduct(){
		$id= $_POST['id'];
		$name = $_POST['name'];
		$price= $_POST['price'];
		$quantity= $_POST['quantity'];
		$this->load->model('ProductModel');
		$this->ProductModel->add($id, $name, $price, $quantity);
		$data['allproducts']=$this->ProductModel->findAll();
		$this->load->helper("url");
		redirect(base_url(), 'refresh');
	}

	public function delete(int $id){
		$this->load->model('ProductModel');
		$this->ProductModel->delete($id);
		$data['allproducts']=$this->ProductModel->findAll();
		$this->load->helper("url");
		redirect(base_url(), 'refresh');
	}

	public function update(int $id){
		$data["id"]=$id;
		$this->load->model('ProductModel');
		$this->load->model('ProductEntity');
		$product=$this->ProductModel->findById($id);
		$data["name"]=$product->getName();
		$data["price"]=$product->getPrice();
		$data["quantity"]=$product->getQuantity();
		$this->load->view('updateProduct', $data);
	}

	public function updateProduct(){
		$id= $_POST['id'];
		$name = $_POST['name'];
		$price= $_POST['price'];
		$quantity= $_POST['quantity'];
		$this->load->model('ProductModel');
		$this->ProductModel->update($id, $name, $price, $quantity);
		$data['allproducts']=$this->ProductModel->findAll();
		$this->load->helper("url");
		redirect(base_url(), 'refresh');
	}
}
