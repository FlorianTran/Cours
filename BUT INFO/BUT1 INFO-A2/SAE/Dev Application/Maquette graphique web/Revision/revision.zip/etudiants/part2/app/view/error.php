<!doctype html>
<html lang="fr">
<head>
    <meta charset="utf-8">
    <title>Mon magasin</title>
</head>
<body>
<p> Echec : <?= 0//TODO ?> </p>
<p> <a href="<?=0 //TODO?>"> Home </a></p>
</body>
</html>
