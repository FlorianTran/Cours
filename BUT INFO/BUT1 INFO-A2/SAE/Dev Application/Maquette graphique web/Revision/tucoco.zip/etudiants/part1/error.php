<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Error</title>
</head>
<body>
    <p> Echec : pas bien </p>
    <a href="debut.html"> Home  </a>
</body>
</html>