<!doctype html>
<html lang="fr">
<head>
    <meta charset="utf-8">
    <title>Mon magasin</title>
</head>
<body>
<p> Echec : <?= "erreur" ?> </p>
<p> <a href="<?= CFG["siteURL"]."User/debut"?>"> Home </a></p>
</body>
</html>
