<?php
//TODO
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Login</title>
</head>
<body>
<p> Welcome : <?=$_POST['login']?></p>
</body>
</html>
