<?php
//TODO
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Login</title>
</head>
<body>
<p> Vegetable : <?= $_POST['name']; ?></p>
<p> Comment : <?= $_POST['comment'];?></p>
</body>
</html>
