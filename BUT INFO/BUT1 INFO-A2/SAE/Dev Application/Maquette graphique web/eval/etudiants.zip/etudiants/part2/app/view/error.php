<!doctype html>
<html lang="fr">
<head>
    <meta charset="utf-8">
    <title>Mon magasin</title>
</head>
<body>
    <p> Error : <?= 'error is not suitable' ?></p>
<p> <a href="<?= CFG['siteURL']."Vegetable/debut";?>"> Home </a></p>
</body>
</html>
