<!doctype html>
<html lang="fr">
<head>
    <meta charset="utf-8">
    <title>Ajout magasin</title>
</head>
<body>
<form action="<?= CFG['siteURL']."Vegetable/check";?>" method="post">
    <input type="text" name="name" placeholder="name">
    <input type="text" name="comment" placeholder="comment">
    <input type="submit">
</form>
</body>
</html>
